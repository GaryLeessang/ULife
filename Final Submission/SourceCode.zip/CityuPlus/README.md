# ULife

#### 介绍
Hong Kong campus application base on Android studio

#### 软件架构
![WorkFlow](img/WorkFlow.png)

#### 参与贡献

1. Fork 本仓库
2. 新建 Feat_xxx 分支
3. 提交代码
4. 新建 Pull Request
