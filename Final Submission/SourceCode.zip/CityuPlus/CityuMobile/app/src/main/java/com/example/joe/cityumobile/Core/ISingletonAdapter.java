package com.example.joe.cityumobile.Core;

public interface ISingletonAdapter {

}
