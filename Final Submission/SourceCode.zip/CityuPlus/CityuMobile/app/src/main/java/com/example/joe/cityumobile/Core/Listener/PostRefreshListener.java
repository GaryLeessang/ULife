package com.example.joe.cityumobile.Core.Listener;

public abstract class PostRefreshListener {

    public abstract void done();

}
