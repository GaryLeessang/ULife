package com.example.joe.cityumobile.Core.Listener;

import java.io.File;

public interface ImageCompressListener {
    void start();
    void done(File path);
}
