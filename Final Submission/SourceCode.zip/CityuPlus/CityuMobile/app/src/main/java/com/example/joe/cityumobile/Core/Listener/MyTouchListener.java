package com.example.joe.cityumobile.Core.Listener;

import android.view.MotionEvent;

public interface MyTouchListener {
    void onTouchEvent(MotionEvent event);
}
