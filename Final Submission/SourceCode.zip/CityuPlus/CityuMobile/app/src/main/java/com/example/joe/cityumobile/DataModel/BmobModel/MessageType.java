package com.example.joe.cityumobile.DataModel.BmobModel;

public class MessageType {
    public static final int TEXT_SEND_TYPE = 0;
    public static final int TEXT_RECEIVE_TYPE = 1;
    public static final int IMG_SEND_TYPE = 2;
    public static final int IMG_RECEIVE_TYPE = 3;
    public static final int CONFIRM_SEND_TYPE = 4;
    public static final int CONFIRM_RECEIVE_TYPE = 5;
}

