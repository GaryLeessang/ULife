package com.example.joe.cityumobile.Core.Listener;

public interface PostPublishListener {
    void done(boolean isSuccess);
}
