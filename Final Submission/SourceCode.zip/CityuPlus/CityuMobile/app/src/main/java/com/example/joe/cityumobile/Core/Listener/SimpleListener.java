package com.example.joe.cityumobile.Core.Listener;

public interface SimpleListener {
    void done();
}
