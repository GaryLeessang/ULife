package com.example.joe.cityumobile.DataAccess;

public class BmobDataAccess {

}
