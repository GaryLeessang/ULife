package com.example.joe.cityumobile.Core.Listener;

import cn.bmob.newim.bean.BmobIMConversation;

public interface ConversationOpenListener {
    void onStarted(BmobIMConversation conversation);
}
